import type { Voxels } from './index.js';
/** Binary Surface Nets, two bounded Jacobi relaxation passes, faceted triangle output. */
type SurfaceMesh = {
    positions: Float32Array;
    normals: Float32Array;
    colors: Float32Array;
    uvs: Float32Array;
    indices: Uint32Array;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: 'smooth' | 'smooth-coarse';
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
        extractionResolution: number;
        smoothingIterations: number;
        ambiguityRepairs: number;
        coarseFallback?: boolean;
    };
};
export declare function meshSurfaceNets(v: Voxels, scale: number, coarse?: boolean): SurfaceMesh;
export {};
