export type TextureStyle = 'natural' | 'minecraft' | 'valheim' | 'tiny' | 'flat';
export type DetailTexture = {
    width: number;
    height: number;
    pixels: Uint8Array;
};
export declare const textureStyles: TextureStyle[];
/** Original procedural palettes/patterns, inspired by broad visual styles; no game assets. */
export declare function styleTexture(base: DetailTexture, style: TextureStyle, seed: number): DetailTexture;
export declare function flatBakedColors(geometry: {
    colors: Float32Array;
    uvs: Float32Array;
    indices: Uint32Array;
}, texture: DetailTexture): Float32Array<ArrayBuffer>;
