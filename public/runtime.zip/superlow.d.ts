import type { Voxels } from './index.js';
type Texture = {
    width: number;
    height: number;
    pixels: Uint8Array;
};
export declare function meshSuperLow(v: Voxels, scale: number, detail: Texture): {
    positions: Float32Array<ArrayBuffer>;
    normals: Float32Array<ArrayBuffer>;
    colors: Float32Array<ArrayBuffer>;
    uvs: Float32Array<ArrayBuffer>;
    indices: Uint32Array<ArrayBuffer>;
    boundingBox: {
        min: number[];
        max: number[];
    };
    texture: {
        width: number;
        height: number;
        pixels: Uint8Array<ArrayBuffer>;
    };
    meshMode: "superlow";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
        sourceTriangles: number;
        targetTriangles: number;
        edgeCollapses: number;
        rebaked: boolean;
    };
};
export {};
