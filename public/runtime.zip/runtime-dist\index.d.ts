export type MeshMode = 'voxel' | 'lowpoly';
export type Family = 'boulder' | 'layered' | 'shard';
export type OpKind = 'mass' | 'cut' | 'chip' | 'layer' | 'noise' | 'block' | 'strata' | 'wedge' | 'fracture';
export type Op = {
    kind: OpKind;
    x: number;
    y: number;
    z: number;
    size: number;
    stretch?: [number, number, number];
    angle?: number;
};
export type Recipe = {
    version: 1 | 2;
    family: Family;
    elongation: number;
    erosion: number;
    hue: number;
    operations: Op[];
};
export type Voxels = {
    version: 1;
    resolution: number;
    cells: Uint8Array;
    palette: number[][];
    provenance?: string;
    material?: {
        family: Family;
        seed: number;
    };
    discardedFraction?: number;
};
export declare const generatorVersion = 2;
export declare function rng(seed: number): () => number;
export declare function validate(r: Recipe): Recipe;
export declare function baseRecipe(family: Family): Recipe;
export declare function sampleVoxels(recipe: Recipe, seed: number, resolution?: number): Voxels;
export declare function stoneTexture(family: Family, seed?: number, size?: number): {
    width: number;
    height: number;
    pixels: Uint8Array<ArrayBuffer>;
};
export declare function meshVoxels(v: Voxels, scale?: number, meshMode?: MeshMode): {
    positions: Float32Array<ArrayBuffer>;
    normals: Float32Array<ArrayBuffer>;
    colors: Float32Array<ArrayBuffer>;
    uvs: Float32Array<ArrayBuffer>;
    indices: Uint32Array<ArrayBuffer>;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "lowpoly";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
    };
} | {
    positions: Float32Array<ArrayBuffer>;
    normals: Float32Array<ArrayBuffer>;
    colors: Float32Array<ArrayBuffer>;
    uvs: Float32Array<ArrayBuffer>;
    indices: Uint32Array<ArrayBuffer>;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "voxel";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
    };
};
export declare function generateRock({ recipe, seed, resolution, scale, meshMode }: {
    recipe: Recipe;
    seed: number;
    resolution?: number;
    scale?: number;
    meshMode?: MeshMode;
}): {
    texture: {
        width: number;
        height: number;
        pixels: Uint8Array<ArrayBuffer>;
    };
    voxels: Voxels;
    positions: Float32Array<ArrayBuffer>;
    normals: Float32Array<ArrayBuffer>;
    colors: Float32Array<ArrayBuffer>;
    uvs: Float32Array<ArrayBuffer>;
    indices: Uint32Array<ArrayBuffer>;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "lowpoly";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
    };
} | {
    texture: {
        width: number;
        height: number;
        pixels: Uint8Array<ArrayBuffer>;
    };
    voxels: Voxels;
    positions: Float32Array<ArrayBuffer>;
    normals: Float32Array<ArrayBuffer>;
    colors: Float32Array<ArrayBuffer>;
    uvs: Float32Array<ArrayBuffer>;
    indices: Uint32Array<ArrayBuffer>;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "voxel";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
    };
};
export declare function parseVoxels(raw: unknown): Voxels;
