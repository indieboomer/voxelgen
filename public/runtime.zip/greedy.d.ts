import type { Voxels } from './index.js';
/** Face culling -> deterministic material-aware greedy rectangles -> two triangles per quad. */
export declare function meshGreedy(v: Voxels, scale: number): {
    positions: Float32Array<ArrayBuffer>;
    normals: Float32Array<ArrayBuffer>;
    colors: Float32Array<ArrayBuffer>;
    uvs: Float32Array<ArrayBuffer>;
    indices: Uint32Array<ArrayBuffer>;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "lowpoly";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
    };
};
