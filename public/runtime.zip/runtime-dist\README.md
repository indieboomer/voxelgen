# Voxel rock runtime 2

Import generateRock from ./index.js. Call generateRock({recipe,seed,resolution:28,scale:1,meshMode:'lowpoly'}).

Returns typed geometry arrays (positions, normals, sRGB vertex colors, UVs, indices), bounding box, voxel data and a 128x128 RGBA stone texture. Colors are sRGB: convert vertex colors to linear in your rendering adapter and mark the color texture as sRGB. Use UVs with the supplied texture, and preserve voxel color boundaries.

Supports recipe interpreters 1 and 2. Version 2 adds block, strata, wedge and fracture operations with optional stretch and yaw. Resolution 12-48; maximum 12 operations. Deterministic u32 seeds. No UI, search, reference-data, network or library dependency.

This package interprets recipe data. It does not specialize/compile each recipe. Empty arbitrary recipes are possible: check positions.length before rendering. Choose meshMode:'voxel' (default) for one quad per exposed voxel face, or 'lowpoly' for material-aware greedy rectangles triangulated into two triangles per quad. Silhouette, material boundaries and planar texture scale remain unchanged. stats reports visibleFaces, quads and triangles. Internal faces are removed; only the largest component is retained; voxels.discardedFraction records discarded material.
