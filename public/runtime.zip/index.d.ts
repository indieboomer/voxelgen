import { type TextureStyle } from './texture-style.js';
export { styleTexture, textureStyles, type TextureStyle } from './texture-style.js';
export type MeshMode = 'voxel' | 'lowpoly' | 'smooth' | 'smooth-coarse' | 'superlow';
export type Family = 'boulder' | 'layered' | 'shard' | 'tree' | 'bush';
export type OpKind = 'mass' | 'cut' | 'chip' | 'layer' | 'noise' | 'block' | 'strata' | 'wedge' | 'fracture' | 'trunk' | 'branch' | 'foliage';
export type Op = {
    kind: OpKind;
    x: number;
    y: number;
    z: number;
    size: number;
    stretch?: [number, number, number];
    angle?: number;
    end?: [number, number, number];
};
export type Recipe = {
    version: 1 | 2 | 3;
    family: Family;
    elongation: number;
    erosion: number;
    hue: number;
    operations: Op[];
};
export type Voxels = {
    version: 1;
    resolution: number;
    cells: Uint8Array;
    palette: number[][];
    provenance?: string;
    material?: {
        family: Family;
        seed: number;
    };
    discardedFraction?: number;
};
export declare const generatorVersion = 3;
export declare function rng(seed: number): () => number;
export declare function validate(r: Recipe): Recipe;
export declare function baseRecipe(family: Family): Recipe;
export declare function sampleVoxels(recipe: Recipe, seed: number, resolution?: number): Voxels;
export declare function stoneTexture(family: Family, seed?: number, size?: number): {
    width: number;
    height: number;
    pixels: Uint8Array<ArrayBuffer>;
};
export declare function meshVoxels(v: Voxels, scale?: number, meshMode?: MeshMode, textureStyle?: TextureStyle): {
    positions: Float32Array;
    normals: Float32Array;
    colors: Float32Array;
    uvs: Float32Array;
    indices: Uint32Array;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "smooth" | "smooth-coarse";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
        extractionResolution: number;
        smoothingIterations: number;
        ambiguityRepairs: number;
        coarseFallback?: boolean;
    };
} | {
    positions: Float32Array<ArrayBuffer>;
    normals: Float32Array<ArrayBuffer>;
    colors: Float32Array<ArrayBuffer>;
    uvs: Float32Array<ArrayBuffer>;
    indices: Uint32Array<ArrayBuffer>;
    boundingBox: {
        min: number[];
        max: number[];
    };
    texture: {
        width: number;
        height: number;
        pixels: Uint8Array<ArrayBuffer>;
    };
    meshMode: "superlow";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
        sourceTriangles: number;
        targetTriangles: number;
        edgeCollapses: number;
        rebaked: boolean;
    };
} | {
    positions: Float32Array<ArrayBuffer>;
    normals: Float32Array<ArrayBuffer>;
    colors: Float32Array<ArrayBuffer>;
    uvs: Float32Array<ArrayBuffer>;
    indices: Uint32Array<ArrayBuffer>;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "lowpoly";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
    };
} | {
    positions: Float32Array<ArrayBuffer>;
    normals: Float32Array<ArrayBuffer>;
    colors: Float32Array<ArrayBuffer>;
    uvs: Float32Array<ArrayBuffer>;
    indices: Uint32Array<ArrayBuffer>;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "voxel";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
    };
} | {
    colors: Float32Array<ArrayBufferLike>;
    texture: import("./texture-style.js").DetailTexture;
    textureStyle: "minecraft" | "valheim" | "tiny" | "flat";
    positions: Float32Array;
    normals: Float32Array;
    uvs: Float32Array;
    indices: Uint32Array;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "smooth" | "smooth-coarse";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
        extractionResolution: number;
        smoothingIterations: number;
        ambiguityRepairs: number;
        coarseFallback?: boolean;
    };
} | {
    colors: Float32Array<ArrayBufferLike>;
    texture: import("./texture-style.js").DetailTexture;
    textureStyle: "minecraft" | "valheim" | "tiny" | "flat";
    positions: Float32Array<ArrayBuffer>;
    normals: Float32Array<ArrayBuffer>;
    uvs: Float32Array<ArrayBuffer>;
    indices: Uint32Array<ArrayBuffer>;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "superlow";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
        sourceTriangles: number;
        targetTriangles: number;
        edgeCollapses: number;
        rebaked: boolean;
    };
} | {
    colors: Float32Array<ArrayBufferLike>;
    texture: import("./texture-style.js").DetailTexture;
    textureStyle: "minecraft" | "valheim" | "tiny" | "flat";
    positions: Float32Array<ArrayBuffer>;
    normals: Float32Array<ArrayBuffer>;
    uvs: Float32Array<ArrayBuffer>;
    indices: Uint32Array<ArrayBuffer>;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "lowpoly";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
    };
} | {
    colors: Float32Array<ArrayBufferLike>;
    texture: import("./texture-style.js").DetailTexture;
    textureStyle: "minecraft" | "valheim" | "tiny" | "flat";
    positions: Float32Array<ArrayBuffer>;
    normals: Float32Array<ArrayBuffer>;
    uvs: Float32Array<ArrayBuffer>;
    indices: Uint32Array<ArrayBuffer>;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "voxel";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
    };
};
export declare function generateRock({ recipe, seed, resolution, scale, meshMode, textureStyle }: {
    recipe: Recipe;
    seed: number;
    resolution?: number;
    scale?: number;
    meshMode?: MeshMode;
    textureStyle?: TextureStyle;
}): {
    texture: import("./texture-style.js").DetailTexture;
    voxels: Voxels;
    positions: Float32Array;
    normals: Float32Array;
    colors: Float32Array;
    uvs: Float32Array;
    indices: Uint32Array;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "smooth" | "smooth-coarse";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
        extractionResolution: number;
        smoothingIterations: number;
        ambiguityRepairs: number;
        coarseFallback?: boolean;
    };
} | {
    texture: import("./texture-style.js").DetailTexture;
    voxels: Voxels;
    positions: Float32Array<ArrayBuffer>;
    normals: Float32Array<ArrayBuffer>;
    colors: Float32Array<ArrayBuffer>;
    uvs: Float32Array<ArrayBuffer>;
    indices: Uint32Array<ArrayBuffer>;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "superlow";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
        sourceTriangles: number;
        targetTriangles: number;
        edgeCollapses: number;
        rebaked: boolean;
    };
} | {
    texture: import("./texture-style.js").DetailTexture;
    voxels: Voxels;
    positions: Float32Array<ArrayBuffer>;
    normals: Float32Array<ArrayBuffer>;
    colors: Float32Array<ArrayBuffer>;
    uvs: Float32Array<ArrayBuffer>;
    indices: Uint32Array<ArrayBuffer>;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "lowpoly";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
    };
} | {
    texture: import("./texture-style.js").DetailTexture;
    voxels: Voxels;
    positions: Float32Array<ArrayBuffer>;
    normals: Float32Array<ArrayBuffer>;
    colors: Float32Array<ArrayBuffer>;
    uvs: Float32Array<ArrayBuffer>;
    indices: Uint32Array<ArrayBuffer>;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "voxel";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
    };
} | {
    texture: import("./texture-style.js").DetailTexture;
    voxels: Voxels;
    colors: Float32Array<ArrayBufferLike>;
    textureStyle: "minecraft" | "valheim" | "tiny" | "flat";
    positions: Float32Array;
    normals: Float32Array;
    uvs: Float32Array;
    indices: Uint32Array;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "smooth" | "smooth-coarse";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
        extractionResolution: number;
        smoothingIterations: number;
        ambiguityRepairs: number;
        coarseFallback?: boolean;
    };
} | {
    texture: import("./texture-style.js").DetailTexture;
    voxels: Voxels;
    colors: Float32Array<ArrayBufferLike>;
    textureStyle: "minecraft" | "valheim" | "tiny" | "flat";
    positions: Float32Array<ArrayBuffer>;
    normals: Float32Array<ArrayBuffer>;
    uvs: Float32Array<ArrayBuffer>;
    indices: Uint32Array<ArrayBuffer>;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "superlow";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
        sourceTriangles: number;
        targetTriangles: number;
        edgeCollapses: number;
        rebaked: boolean;
    };
} | {
    texture: import("./texture-style.js").DetailTexture;
    voxels: Voxels;
    colors: Float32Array<ArrayBufferLike>;
    textureStyle: "minecraft" | "valheim" | "tiny" | "flat";
    positions: Float32Array<ArrayBuffer>;
    normals: Float32Array<ArrayBuffer>;
    uvs: Float32Array<ArrayBuffer>;
    indices: Uint32Array<ArrayBuffer>;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "lowpoly";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
    };
} | {
    texture: import("./texture-style.js").DetailTexture;
    voxels: Voxels;
    colors: Float32Array<ArrayBufferLike>;
    textureStyle: "minecraft" | "valheim" | "tiny" | "flat";
    positions: Float32Array<ArrayBuffer>;
    normals: Float32Array<ArrayBuffer>;
    uvs: Float32Array<ArrayBuffer>;
    indices: Uint32Array<ArrayBuffer>;
    boundingBox: {
        min: number[];
        max: number[];
    };
    meshMode: "voxel";
    stats: {
        visibleFaces: number;
        quads: number;
        triangles: number;
    };
};
export declare function parseVoxels(raw: unknown): Voxels;
